// components/YoutubeLogin.tsx
"use client";
import { useRouter } from "next/navigation";
import { generateCodeVerifier, sha256Base64Url } from "@/utils/pkce";

export default function YoutubeLogin() {
  const router = useRouter();

  const handleClick = async () => {
    const state        = crypto.randomUUID();
    const codeVerifier = generateCodeVerifier();             // 128 random chars
    const codeChallenge= await sha256Base64Url(codeVerifier);

    // 保存 (Cookie でも sessionStorage でも可)
    sessionStorage.setItem("code_verifier", codeVerifier);
    sessionStorage.setItem("pkce_state", state);

    const params = new URLSearchParams({
      client_id: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID,
      redirect_uri: `${window.location.origin}/api/oauth2callback`,
      response_type: "code",
      scope: "https://www.googleapis.com/auth/youtube.readonly",
      access_type: "offline",             // refresh_token を得る
      include_granted_scopes: "true",
      state,
      code_challenge: codeChallenge,
      code_challenge_method: "S256",
    });

    window.location.href =
      `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
  };

  return <button onClick={handleClick}>YouTube チャンネルを紐づけ</button>;
}
