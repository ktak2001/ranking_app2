// app/api/oauth2callback/route.ts
import { NextRequest, NextResponse } from "next/server";
import axios from "axios";
import { db } from "@/lib/firebase"; // admin SDK
import { getAuth } from "firebase-admin/auth";

export async function GET(req) {
  const url   = new URL(req.url);
  const code  = url.searchParams.get("code");
  const state = url.searchParams.get("state");

  const storedState = await req.cookies.get("pkce_state")?.value
                  ?? sessionStorage.getItem("pkce_state");
  if (state !== storedState) {
    return NextResponse.json({error: "state mismatch"}, {status:400});
  }

  const codeVerifier =
        sessionStorage.getItem("code_verifier") ?? "";

  // ---- トークンエンドポイント ----
  const tokenRes = await axios.post(
    "https://oauth2.googleapis.com/token",
    new URLSearchParams({
      client_id: process.env.GOOGLE_CLIENT_ID,
      grant_type: "authorization_code",
      code: code ?? "",
      redirect_uri: `${url.origin}/api/oauth2callback`,
      code_verifier: codeVerifier,
    })
  );
  const { access_token, refresh_token, expires_in } = tokenRes.data;

  // ---- YouTube API でチャンネル ID を取得 ----
  const yt = await axios.get(
    "https://youtube.googleapis.com/youtube/v3/channels",
    {
      params: { part: "id", mine: "true" },
      headers: { Authorization: `Bearer ${access_token}` },
    }
  );
  const supporterId = yt.data.items[0].id;

  // ---- Firebase に保存 ----
  const sessionCookie = req.cookies.get("__session")?.value;
  const decoded = await getAuth().verifySessionCookie(sessionCookie);
  const uid = decoded.uid;

  await db.collection("users").doc(uid).set(
    {
      supporterId,
      youtube: {
        accessToken: access_token,
        refreshToken: refresh_token,
        expiresAt: Date.now() + expires_in * 1000,
      },
    },
    { merge: true }
  );

  // optional: setHeader("Set-Cookie", ...)
  return NextResponse.redirect(new URL("/?ytLinked=1", url.origin));
}
